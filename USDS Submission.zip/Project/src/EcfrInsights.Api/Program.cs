using EcfrInsights.Api.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ADO helper (raw ADO.NET + stored procedures)
builder.Services.AddSingleton<Ado>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

// Static UI hosting
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();

app.Run();
