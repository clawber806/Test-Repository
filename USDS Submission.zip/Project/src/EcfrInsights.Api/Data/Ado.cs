using Microsoft.Data.SqlClient;
using System.Data;
using EcfrInsights.Api.Utils;

namespace EcfrInsights.Api.Data;

public sealed class Ado(IConfiguration config)
{
    private readonly string _cs = config.GetConnectionString("Db")!;

    public SqlConnection CreateConnection() => new(_cs);

    public async Task<List<Dictionary<string, object?>>> QueryAsync(
        string procName,
        IEnumerable<SqlParameter>? parameters = null,
        CancellationToken ct = default)
    {
        using var conn = CreateConnection();
        await conn.OpenAsync(ct);

        using var cmd = new SqlCommand(procName, conn)
        {
            CommandType = CommandType.StoredProcedure
        };

        if (parameters != null)
            cmd.Parameters.AddRange(parameters.ToArray());

        using var reader = await cmd.ExecuteReaderAsync(ct);

        var results = new List<Dictionary<string, object?>>();
        while (await reader.ReadAsync(ct))
        {
            var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < reader.FieldCount; i++)
            {
                var name = reader.GetName(i);
                var val = await reader.IsDBNullAsync(i, ct) ? null : reader.GetValue(i);
                row[name] = val;
            }
            results.Add(row);
        }

        return JsonKeyCase.ToCamelCaseList(results);
    }

    public async Task<Dictionary<string, object?>?> QueryFirstOrDefaultAsync(
        string procName,
        IEnumerable<SqlParameter>? parameters = null,
        CancellationToken ct = default)
    {
        var rows = await QueryAsync(procName, parameters, ct);
        return rows.Count > 0 ? rows[0] : null;
    }
}
