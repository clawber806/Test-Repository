using System.Text;

namespace EcfrInsights.Api.Utils;

public static class JsonKeyCase
{
    public static string ToCamelCase(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) return name;

        if (name.Contains('_'))
        {
            var parts = name.Split('_', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) return name;

            var sb = new StringBuilder();
            sb.Append(parts[0].ToLowerInvariant());

            for (int i = 1; i < parts.Length; i++)
            {
                var p = parts[i];
                if (p.Length == 0) continue;
                sb.Append(char.ToUpperInvariant(p[0]));
                if (p.Length > 1) sb.Append(p.Substring(1).ToLowerInvariant());
            }
            return sb.ToString();
        }

        if (char.IsLower(name[0])) return name;
        return char.ToLowerInvariant(name[0]) + name[1..];
    }

    public static Dictionary<string, object?> ToCamelCaseDictionary(Dictionary<string, object?> row)
    {
        var normalized = new Dictionary<string, object?>(StringComparer.Ordinal);
        foreach (var kv in row)
            normalized[ToCamelCase(kv.Key)] = kv.Value;
        return normalized;
    }

    public static List<Dictionary<string, object?>> ToCamelCaseList(List<Dictionary<string, object?>> rows)
        => rows.Select(ToCamelCaseDictionary).ToList();
}
