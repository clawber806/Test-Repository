using EcfrInsights.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace EcfrInsights.Api.Controllers;

[ApiController]
[Route("api/rankings")]
public class RankingsController(Ado ado) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string metric = "restrictionDensity",
                                         [FromQuery] string? snapshotDate = null,
                                         [FromQuery] int limit = 20,
                                         CancellationToken ct = default)
    {
        var p = new List<SqlParameter>
        {
            new("@Metric", SqlDbType.NVarChar, 32) { Value = metric },
            new("@SnapshotDate", SqlDbType.Date) { Value = (object?)TryParseDate(snapshotDate) ?? DBNull.Value },
            new("@Limit", SqlDbType.Int) { Value = limit }
        };

        var items = await ado.QueryAsync("ecfr.usp_GetRankings", p, ct);
        return Ok(new { metric, snapshotDate, items });
    }

    private static DateTime? TryParseDate(string? s)
        => DateTime.TryParse(s, out var d) ? d.Date : null;
}
