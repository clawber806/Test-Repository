using EcfrInsights.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace EcfrInsights.Api.Controllers;

[ApiController]
[Route("api/agencies")]
public class AgenciesController(Ado ado) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? snapshotDate, CancellationToken ct)
    {
        var p = new List<SqlParameter>
        {
            new("@SnapshotDate", SqlDbType.Date) { Value = (object?)TryParseDate(snapshotDate) ?? DBNull.Value }
        };

        var rows = await ado.QueryAsync("ecfr.usp_ListAgenciesForSnapshot", p, ct);

        var resolved = rows.FirstOrDefault()?.GetValueOrDefault("snapshotDate")?.ToString() ?? snapshotDate;
        return Ok(new { snapshotDate = resolved, items = rows });
    }

    private static DateTime? TryParseDate(string? s)
        => DateTime.TryParse(s, out var d) ? d.Date : null;
}
