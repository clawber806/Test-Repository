-- db/seed.sql
-- Minimal seed data so UI works without ingestion

DECLARE @s1 UNIQUEIDENTIFIER = NEWID();
DECLARE @s2 UNIQUEIDENTIFIER = NEWID();

INSERT INTO ecfr.Snapshots (Id, SnapshotDate, Source)
VALUES
(@s1, '2025-12-01', 'seed'),
(@s2, '2025-12-15', 'seed');

DECLARE @a1 UNIQUEIDENTIFIER = NEWID();
DECLARE @a2 UNIQUEIDENTIFIER = NEWID();
DECLARE @a3 UNIQUEIDENTIFIER = NEWID();
DECLARE @a4 UNIQUEIDENTIFIER = NEWID();
DECLARE @a5 UNIQUEIDENTIFIER = NEWID();

INSERT INTO ecfr.Agencies (Id, Name, Slug)
VALUES
(@a1, 'Environmental Protection Agency', 'environmental-protection-agency'),
(@a2, 'Department of Transportation', 'department-of-transportation'),
(@a3, 'Food and Drug Administration', 'food-and-drug-administration'),
(@a4, 'Federal Communications Commission', 'federal-communications-commission'),
(@a5, 'Department of Labor', 'department-of-labor');

INSERT INTO ecfr.AgencyMetrics (Id, SnapshotId, AgencyId, WordCount, SectionCount, ChecksumSha256, RestrictionDensity)
VALUES
(NEWID(), @s1, @a1, 1200000, 5200, REPLICATE('a',64), 8.40),
(NEWID(), @s1, @a2,  950000, 4100, REPLICATE('b',64), 6.10),
(NEWID(), @s1, @a3,  780000, 3300, REPLICATE('c',64), 9.75),
(NEWID(), @s1, @a4,  410000, 1800, REPLICATE('d',64), 7.20),
(NEWID(), @s1, @a5,  670000, 2900, REPLICATE('e',64), 5.55);

INSERT INTO ecfr.AgencyMetrics (Id, SnapshotId, AgencyId, WordCount, SectionCount, ChecksumSha256, RestrictionDensity)
VALUES
(NEWID(), @s2, @a1, 1215000, 5275, REPLICATE('f',64), 8.55),
(NEWID(), @s2, @a2,  948000, 4095, REPLICATE('b',64), 6.05),
(NEWID(), @s2, @a3,  810000, 3420, REPLICATE('g',64), 9.20),
(NEWID(), @s2, @a4,  410000, 1800, REPLICATE('d',64), 7.20),
(NEWID(), @s2, @a5,  655000, 2860, REPLICATE('h',64), 5.80);
