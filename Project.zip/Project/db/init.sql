IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ecfr')
    EXEC('CREATE SCHEMA ecfr');
GO

IF OBJECT_ID('ecfr.Snapshots', 'U') IS NULL
BEGIN
    CREATE TABLE ecfr.Snapshots (
        Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Snapshots PRIMARY KEY,
        SnapshotDate DATE NOT NULL,
        Source NVARCHAR(64) NOT NULL CONSTRAINT DF_Snapshots_Source DEFAULT('govinfo_bulk_ecfr'),
        IngestedAt DATETIMEOFFSET NOT NULL CONSTRAINT DF_Snapshots_IngestedAt DEFAULT (SYSDATETIMEOFFSET()),
        Notes NVARCHAR(MAX) NULL
    );
    CREATE UNIQUE INDEX UX_Snapshots_SnapshotDate ON ecfr.Snapshots(SnapshotDate);
END
GO

IF OBJECT_ID('ecfr.Agencies', 'U') IS NULL
BEGIN
    CREATE TABLE ecfr.Agencies (
        Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Agencies PRIMARY KEY,
        Name NVARCHAR(256) NOT NULL,
        Slug NVARCHAR(256) NOT NULL
    );
    CREATE UNIQUE INDEX UX_Agencies_Name ON ecfr.Agencies(Name);
    CREATE UNIQUE INDEX UX_Agencies_Slug ON ecfr.Agencies(Slug);
END
GO

IF OBJECT_ID('ecfr.AgencyMetrics', 'U') IS NULL
BEGIN
    CREATE TABLE ecfr.AgencyMetrics (
        Id UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_AgencyMetrics PRIMARY KEY,
        SnapshotId UNIQUEIDENTIFIER NOT NULL,
        AgencyId UNIQUEIDENTIFIER NOT NULL,
        WordCount BIGINT NOT NULL,
        SectionCount INT NOT NULL,
        ChecksumSha256 CHAR(64) NOT NULL,
        RestrictionDensity FLOAT NOT NULL,
        CONSTRAINT FK_AgencyMetrics_Snapshots FOREIGN KEY (SnapshotId) REFERENCES ecfr.Snapshots(Id),
        CONSTRAINT FK_AgencyMetrics_Agencies FOREIGN KEY (AgencyId) REFERENCES ecfr.Agencies(Id)
    );
    CREATE UNIQUE INDEX UX_AgencyMetrics_Snapshot_Agency ON ecfr.AgencyMetrics(SnapshotId, AgencyId);
    CREATE INDEX IX_AgencyMetrics_Snapshot_WordCount ON ecfr.AgencyMetrics(SnapshotId, WordCount DESC);
    CREATE INDEX IX_AgencyMetrics_Snapshot_RestrictionDensity ON ecfr.AgencyMetrics(SnapshotId, RestrictionDensity DESC);
END
GO

CREATE OR ALTER PROCEDURE ecfr.usp_ListSnapshots
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id,
           CONVERT(varchar(10), SnapshotDate, 23) AS SnapshotDate,
           Source,
           IngestedAt
    FROM ecfr.Snapshots
    ORDER BY SnapshotDate DESC;
END
GO

CREATE OR ALTER PROCEDURE ecfr.usp_ListAgenciesForSnapshot
    @SnapshotDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @SnapshotDate IS NULL
        SELECT TOP (1) @SnapshotDate = SnapshotDate FROM ecfr.Snapshots ORDER BY SnapshotDate DESC;

    DECLARE @SnapshotId UNIQUEIDENTIFIER;
    SELECT @SnapshotId = Id FROM ecfr.Snapshots WHERE SnapshotDate = @SnapshotDate;

    SELECT a.Name,
           a.Slug,
           m.WordCount,
           m.SectionCount,
           m.RestrictionDensity,
           m.ChecksumSha256,
           CONVERT(varchar(10), @SnapshotDate, 23) AS SnapshotDate
    FROM ecfr.AgencyMetrics m
    JOIN ecfr.Agencies a ON a.Id = m.AgencyId
    WHERE m.SnapshotId = @SnapshotId
    ORDER BY m.WordCount DESC;
END
GO

CREATE OR ALTER PROCEDURE ecfr.usp_GetRankings
    @Metric NVARCHAR(32) = N'restrictionDensity',
    @SnapshotDate DATE = NULL,
    @Limit INT = 20
AS
BEGIN
    SET NOCOUNT ON;

    IF LOWER(@Metric) NOT IN ('wordcount','sectioncount','restrictiondensity')
    BEGIN
        RAISERROR('Invalid metric.', 16, 1);
        RETURN;
    END

    IF @SnapshotDate IS NULL
        SELECT TOP (1) @SnapshotDate = SnapshotDate FROM ecfr.Snapshots ORDER BY SnapshotDate DESC;

    DECLARE @SnapshotId UNIQUEIDENTIFIER;
    SELECT @SnapshotId = Id FROM ecfr.Snapshots WHERE SnapshotDate = @SnapshotDate;

    SELECT TOP (@Limit)
        a.Name,
        a.Slug,
        CASE LOWER(@Metric)
            WHEN 'wordcount' THEN CONVERT(float, m.WordCount)
            WHEN 'sectioncount' THEN CONVERT(float, m.SectionCount)
            ELSE m.RestrictionDensity
        END AS [Value],
        CONVERT(varchar(10), @SnapshotDate, 23) AS SnapshotDate
    FROM ecfr.AgencyMetrics m
    JOIN ecfr.Agencies a ON a.Id = m.AgencyId
    WHERE m.SnapshotId = @SnapshotId
    ORDER BY
        CASE LOWER(@Metric)
            WHEN 'wordcount' THEN CONVERT(float, m.WordCount)
            WHEN 'sectioncount' THEN CONVERT(float, m.SectionCount)
            ELSE m.RestrictionDensity
        END DESC;
END
GO

CREATE OR ALTER PROCEDURE ecfr.usp_GetChanges
    @FromDate DATE,
    @ToDate DATE,
    @Metric NVARCHAR(32) = N'wordCount',
    @Limit INT = 20
AS
BEGIN
    SET NOCOUNT ON;

    IF LOWER(@Metric) NOT IN ('wordcount','sectioncount','restrictiondensity')
    BEGIN
        RAISERROR('Invalid metric.', 16, 1);
        RETURN;
    END

    DECLARE @FromId UNIQUEIDENTIFIER, @ToId UNIQUEIDENTIFIER;
    SELECT @FromId = Id FROM ecfr.Snapshots WHERE SnapshotDate = @FromDate;
    SELECT @ToId = Id FROM ecfr.Snapshots WHERE SnapshotDate = @ToDate;

    IF @FromId IS NULL OR @ToId IS NULL
    BEGIN
        RAISERROR('One or both snapshots not found.', 16, 1);
        RETURN;
    END

    ;WITH Joined AS (
        SELECT a.Name,
               a.Slug,
               m1.WordCount AS FromWordCount,
               m2.WordCount AS ToWordCount,
               m1.SectionCount AS FromSectionCount,
               m2.SectionCount AS ToSectionCount,
               m1.RestrictionDensity AS FromRestrictionDensity,
               m2.RestrictionDensity AS ToRestrictionDensity,
               m1.ChecksumSha256 AS FromChecksum,
               m2.ChecksumSha256 AS ToChecksum
        FROM ecfr.AgencyMetrics m1
        JOIN ecfr.AgencyMetrics m2 ON m1.AgencyId = m2.AgencyId
        JOIN ecfr.Agencies a ON a.Id = m1.AgencyId
        WHERE m1.SnapshotId = @FromId AND m2.SnapshotId = @ToId
    )
    SELECT TOP (@Limit)
        Name,
        Slug,
        CASE LOWER(@Metric)
            WHEN 'wordcount' THEN CONVERT(float, FromWordCount)
            WHEN 'sectioncount' THEN CONVERT(float, FromSectionCount)
            ELSE FromRestrictionDensity
        END AS FromValue,
        CASE LOWER(@Metric)
            WHEN 'wordcount' THEN CONVERT(float, ToWordCount)
            WHEN 'sectioncount' THEN CONVERT(float, ToSectionCount)
            ELSE ToRestrictionDensity
        END AS ToValue,
        CASE LOWER(@Metric)
            WHEN 'wordcount' THEN CONVERT(float, ToWordCount - FromWordCount)
            WHEN 'sectioncount' THEN CONVERT(float, ToSectionCount - FromSectionCount)
            ELSE (ToRestrictionDensity - FromRestrictionDensity)
        END AS Delta,
        CASE WHEN FromChecksum <> ToChecksum THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS ChecksumChanged,
        CASE
            WHEN FromWordCount IS NULL OR FromWordCount = 0 THEN 0.0
            ELSE
                CASE LOWER(@Metric)
                    WHEN 'wordcount' THEN ((ToWordCount - FromWordCount) * 10000.0) / FromWordCount
                    WHEN 'sectioncount' THEN ((ToSectionCount - FromSectionCount) * 10000.0) / FromWordCount
                    ELSE ((ToRestrictionDensity - FromRestrictionDensity) * 10000.0) / FromWordCount
                END
        END AS NormalizedDeltaPer10kWords
    FROM Joined
    ORDER BY Delta DESC;
END
GO
