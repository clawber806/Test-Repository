using EcfrInsights.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace EcfrInsights.Api.Controllers;

[ApiController]
[Route("api/changes")]
public class ChangesController(Ado ado) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string fromDate,
                                         [FromQuery] string toDate,
                                         [FromQuery] string metric = "wordCount",
                                         [FromQuery] int limit = 20,
                                         CancellationToken ct = default)
    {
        if (!DateTime.TryParse(fromDate, out var f) || !DateTime.TryParse(toDate, out var t))
            return BadRequest("fromDate/toDate must be YYYY-MM-DD.");

        var p = new List<SqlParameter>
        {
            new("@FromDate", SqlDbType.Date) { Value = f.Date },
            new("@ToDate", SqlDbType.Date) { Value = t.Date },
            new("@Metric", SqlDbType.NVarChar, 32) { Value = metric },
            new("@Limit", SqlDbType.Int) { Value = limit }
        };

        var items = await ado.QueryAsync("ecfr.usp_GetChanges", p, ct);
        return Ok(new { fromDate, toDate, metric, items });
    }
}
