using EcfrInsights.Api.Data;
using Microsoft.AspNetCore.Mvc;

namespace EcfrInsights.Api.Controllers;

[ApiController]
[Route("api/snapshots")]
public class SnapshotsController(Ado ado) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(CancellationToken ct)
    {
        var rows = await ado.QueryAsync("ecfr.usp_ListSnapshots", null, ct);
        return Ok(rows);
    }
}
