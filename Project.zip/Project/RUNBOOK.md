# RUNBOOK

## Start
From the repository root:

```bash
docker compose up --build
```

## Open
- UI: http://localhost:8000/
- Changes view: http://localhost:8000/changes.html
- Swagger: http://localhost:8000/swagger
- API check: http://localhost:8000/api/snapshots

## Troubleshooting
- If UI 404s: verify `Program.cs` includes `UseDefaultFiles()` + `UseStaticFiles()` and `wwwroot/index.html` exists.
- If DB init fails: `docker compose logs -f db-init`
- If API cannot reach DB: `docker compose logs -f api`
