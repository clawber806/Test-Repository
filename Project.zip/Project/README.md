# eCFR Insights — Regulatory Analysis Prototype

## Purpose
Federal regulations are large, complex, and constantly changing. This prototype demonstrates a practical approach to transforming eCFR regulatory text into clear, repeatable signals that help teams prioritize deeper review.

This project emphasizes:
- user-centered analysis workflows (compare, rank, drill down, export),
- transparency and auditability (explicit stored procedures),
- reproducible snapshot-based comparisons.

## What the system provides
- **Word count**: proxy for regulatory footprint size.
- **Section count**: proxy for structural complexity.
- **Restriction density (custom metric)**: directive-language frequency (e.g., “shall”, “must”, “required”) normalized per 1,000 words.
- **Checksum (SHA-256)**: deterministic change detection across snapshots.
- **Normalized change per 10,000 words**: size-adjusted comparisons across agencies of different sizes.

## Architecture
- **Backend**: ASP.NET Core 8 Web API
- **Database**: SQL Server with **T-SQL stored procedures** for analytics
- **Data Access**: ADO.NET (no ORM) for explicit, auditable access
- **Frontend**: plain HTML + JavaScript served from `wwwroot` (no build step)

## Run (Recommended)
This repository includes a Docker-based environment that runs:
- SQL Server
- One-time database initialization (schema + stored procedures + demo seed data)
- ASP.NET Core API that serves the UI as static files

### Prerequisites
- Docker Desktop

### Start
```bash
docker compose up --build
```

### Open
- UI: http://localhost:8000/
- Changes view: http://localhost:8000/changes.html
- Swagger: http://localhost:8000/swagger
- Verify data: http://localhost:8000/api/snapshots

## Sample data
To ensure the UI is usable immediately (even if ingestion is not executed), the repo includes:
- `db/init.sql` — schema + stored procedures
- `db/seed.sql` — two snapshots + sample agencies + metrics

## Notes
- This prototype supports initial screening and prioritization; it does not automate policy decisions.
- Checksum-based change detection provides a reliable signal that text changed, without requiring full diffs.
